const sdk = require('node-appwrite');

console.log(process.env);
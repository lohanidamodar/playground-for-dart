import json 
import os
from appwrite.client import Client
from appwrite.services.storage import Storage


print(os.environ);

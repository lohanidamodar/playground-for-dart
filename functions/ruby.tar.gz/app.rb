require 'appwrite'

client = Appwrite::Client.new()

puts ENV.map { |k,v| "#{k} = #{v}" }.join("\n")
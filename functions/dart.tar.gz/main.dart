import "dart:io";
import "package:dart_appwrite/dart_appwrite.dart";

void main() { // Init SDK
  print(Platform.environment);
}
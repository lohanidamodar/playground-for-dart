export 'src/entry/dio_for_browser.dart' show DioForBrowser;

import '../dio.dart';

Dio createDio([BaseOptions options]) => throw UnsupportedError('');

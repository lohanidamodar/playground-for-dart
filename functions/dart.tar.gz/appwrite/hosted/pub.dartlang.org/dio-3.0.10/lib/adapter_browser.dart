export 'src/adapters/browser_adapter.dart' show BrowserHttpClientAdapter;

export 'src/entry/dio_for_native.dart' show DioForNative;

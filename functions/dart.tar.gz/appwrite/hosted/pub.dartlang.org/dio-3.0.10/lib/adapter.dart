export 'src/adapters/io_adapter.dart' show DefaultHttpClientAdapter;

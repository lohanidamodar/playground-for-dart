## 1.1.3

- Added example, fixed recommended lints.

## 1.1.2

- Updated the SDK constraint.

## 1.1.1

- Spelling fixes.

- Linting fixes.

## 1.1.0

- Initial version

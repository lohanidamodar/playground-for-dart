<?php

include './vendor/autoload.php';

use Appwrite\Client;
use Appwrite\Services\Storage;

print_r($_ENV);

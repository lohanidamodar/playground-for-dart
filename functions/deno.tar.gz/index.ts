import * as sdk from "https://deno.land/x/appwrite/mod.ts";

console.log(Deno.env.toObject());
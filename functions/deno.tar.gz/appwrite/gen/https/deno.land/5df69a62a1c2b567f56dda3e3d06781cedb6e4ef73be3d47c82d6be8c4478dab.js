import { Service } from "../service.ts";
export class Functions extends Service {
    async list(search = '', limit = 25, offset = 0, orderType = 'ASC') {
        let path = '/functions';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {
            'search': search,
            'limit': limit,
            'offset': offset,
            'orderType': orderType
        });
    }
    async create(name, execute, env, vars = {}, events = [], schedule = '', timeout = 15) {
        let path = '/functions';
        return await this.client.call('post', path, {
            'content-type': 'application/json',
        }, {
            'name': name,
            'execute': execute,
            'env': env,
            'vars': vars,
            'events': events,
            'schedule': schedule,
            'timeout': timeout
        });
    }
    async get(functionId) {
        let path = '/functions/{functionId}'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async update(functionId, name, execute, vars = {}, events = [], schedule = '', timeout = 15) {
        let path = '/functions/{functionId}'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('put', path, {
            'content-type': 'application/json',
        }, {
            'name': name,
            'execute': execute,
            'vars': vars,
            'events': events,
            'schedule': schedule,
            'timeout': timeout
        });
    }
    async delete(functionId) {
        let path = '/functions/{functionId}'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('delete', path, {
            'content-type': 'application/json',
        }, {});
    }
    async listExecutions(functionId, search = '', limit = 25, offset = 0, orderType = 'ASC') {
        let path = '/functions/{functionId}/executions'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {
            'search': search,
            'limit': limit,
            'offset': offset,
            'orderType': orderType
        });
    }
    async createExecution(functionId) {
        let path = '/functions/{functionId}/executions'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('post', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getExecution(functionId, executionId) {
        let path = '/functions/{functionId}/executions/{executionId}'.replace(new RegExp('{functionId}', 'g'), functionId).replace(new RegExp('{executionId}', 'g'), executionId);
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async updateTag(functionId, tag) {
        let path = '/functions/{functionId}/tag'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('patch', path, {
            'content-type': 'application/json',
        }, {
            'tag': tag
        });
    }
    async listTags(functionId, search = '', limit = 25, offset = 0, orderType = 'ASC') {
        let path = '/functions/{functionId}/tags'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {
            'search': search,
            'limit': limit,
            'offset': offset,
            'orderType': orderType
        });
    }
    async createTag(functionId, command, code) {
        let path = '/functions/{functionId}/tags'.replace(new RegExp('{functionId}', 'g'), functionId);
        return await this.client.call('post', path, {
            'content-type': 'multipart/form-data',
        }, {
            'command': command,
            'code': code
        });
    }
    async getTag(functionId, tagId) {
        let path = '/functions/{functionId}/tags/{tagId}'.replace(new RegExp('{functionId}', 'g'), functionId).replace(new RegExp('{tagId}', 'g'), tagId);
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async deleteTag(functionId, tagId) {
        let path = '/functions/{functionId}/tags/{tagId}'.replace(new RegExp('{functionId}', 'g'), functionId).replace(new RegExp('{tagId}', 'g'), tagId);
        return await this.client.call('delete', path, {
            'content-type': 'application/json',
        }, {});
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnVuY3Rpb25zLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZnVuY3Rpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHeEMsTUFBTSxPQUFPLFNBQVUsU0FBUSxPQUFPO0lBZWxDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBaUIsRUFBRSxFQUFFLFFBQWdCLEVBQUUsRUFBRSxTQUFpQixDQUFDLEVBQUUsWUFBb0IsS0FBSztRQUM3RixJQUFJLElBQUksR0FBRyxZQUFZLENBQUM7UUFFeEIsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNEO1lBQ0MsUUFBUSxFQUFFLE1BQU07WUFDaEIsT0FBTyxFQUFFLEtBQUs7WUFDZCxRQUFRLEVBQUUsTUFBTTtZQUNoQixXQUFXLEVBQUUsU0FBUztTQUN6QixDQUFDLENBQUM7SUFDWCxDQUFDO0lBbUJELEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBWSxFQUFFLE9BQW1CLEVBQUUsR0FBVyxFQUFFLE9BQXFCLEVBQUUsRUFBRSxTQUFxQixFQUFFLEVBQUUsV0FBbUIsRUFBRSxFQUFFLFVBQWtCLEVBQUU7UUFDdEosSUFBSSxJQUFJLEdBQUcsWUFBWSxDQUFDO1FBRXhCLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFO1lBQ2hDLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRDtZQUNDLE1BQU0sRUFBRSxJQUFJO1lBQ1osU0FBUyxFQUFFLE9BQU87WUFDbEIsS0FBSyxFQUFFLEdBQUc7WUFDVixNQUFNLEVBQUUsSUFBSTtZQUNaLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFVBQVUsRUFBRSxRQUFRO1lBQ3BCLFNBQVMsRUFBRSxPQUFPO1NBQ3JCLENBQUMsQ0FBQztJQUNYLENBQUM7SUFXRCxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQWtCO1FBQ3hCLElBQUksSUFBSSxHQUFHLHlCQUF5QixDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFMUYsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQWlCRCxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQWtCLEVBQUUsSUFBWSxFQUFFLE9BQW1CLEVBQUUsT0FBcUIsRUFBRSxFQUFFLFNBQXFCLEVBQUUsRUFBRSxXQUFtQixFQUFFLEVBQUUsVUFBa0IsRUFBRTtRQUM3SixJQUFJLElBQUksR0FBRyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRTFGLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO1lBQy9CLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRDtZQUNDLE1BQU0sRUFBRSxJQUFJO1lBQ1osU0FBUyxFQUFFLE9BQU87WUFDbEIsTUFBTSxFQUFFLElBQUk7WUFDWixRQUFRLEVBQUUsTUFBTTtZQUNoQixVQUFVLEVBQUUsUUFBUTtZQUNwQixTQUFTLEVBQUUsT0FBTztTQUNyQixDQUFDLENBQUM7SUFDWCxDQUFDO0lBV0QsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFrQjtRQUMzQixJQUFJLElBQUksR0FBRyx5QkFBeUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRTFGLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFO1lBQ2xDLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRCxFQUNGLENBQUMsQ0FBQztJQUNYLENBQUM7SUFrQkQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFrQixFQUFFLFNBQWlCLEVBQUUsRUFBRSxRQUFnQixFQUFFLEVBQUUsU0FBaUIsQ0FBQyxFQUFFLFlBQW9CLEtBQUs7UUFDM0gsSUFBSSxJQUFJLEdBQUcsb0NBQW9DLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUVyRyxPQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRTtZQUMvQixjQUFjLEVBQUUsa0JBQWtCO1NBQ3RDLEVBQ0Q7WUFDQyxRQUFRLEVBQUUsTUFBTTtZQUNoQixPQUFPLEVBQUUsS0FBSztZQUNkLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFdBQVcsRUFBRSxTQUFTO1NBQ3pCLENBQUMsQ0FBQztJQUNYLENBQUM7SUFjRCxLQUFLLENBQUMsZUFBZSxDQUFDLFVBQWtCO1FBQ3BDLElBQUksSUFBSSxHQUFHLG9DQUFvQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFckcsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUU7WUFDaEMsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVlELEtBQUssQ0FBQyxZQUFZLENBQUMsVUFBa0IsRUFBRSxXQUFtQjtRQUN0RCxJQUFJLElBQUksR0FBRyxrREFBa0QsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFFMUssT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQWNELEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBa0IsRUFBRSxHQUFXO1FBQzNDLElBQUksSUFBSSxHQUFHLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFOUYsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUU7WUFDakMsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNEO1lBQ0MsS0FBSyxFQUFFLEdBQUc7U0FDYixDQUFDLENBQUM7SUFDWCxDQUFDO0lBZ0JELEtBQUssQ0FBQyxRQUFRLENBQUMsVUFBa0IsRUFBRSxTQUFpQixFQUFFLEVBQUUsUUFBZ0IsRUFBRSxFQUFFLFNBQWlCLENBQUMsRUFBRSxZQUFvQixLQUFLO1FBQ3JILElBQUksSUFBSSxHQUFHLDhCQUE4QixDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFL0YsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNEO1lBQ0MsUUFBUSxFQUFFLE1BQU07WUFDaEIsT0FBTyxFQUFFLEtBQUs7WUFDZCxRQUFRLEVBQUUsTUFBTTtZQUNoQixXQUFXLEVBQUUsU0FBUztTQUN6QixDQUFDLENBQUM7SUFDWCxDQUFDO0lBc0JELEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBa0IsRUFBRSxPQUFlLEVBQUUsSUFBaUI7UUFDbEUsSUFBSSxJQUFJLEdBQUcsOEJBQThCLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUUvRixPQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRTtZQUNoQyxjQUFjLEVBQUUscUJBQXFCO1NBQ3pDLEVBQ0Q7WUFDQyxTQUFTLEVBQUUsT0FBTztZQUNsQixNQUFNLEVBQUUsSUFBSTtTQUNmLENBQUMsQ0FBQztJQUNYLENBQUM7SUFZRCxLQUFLLENBQUMsTUFBTSxDQUFDLFVBQWtCLEVBQUUsS0FBYTtRQUMxQyxJQUFJLElBQUksR0FBRyxzQ0FBc0MsQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFbEosT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVlELEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBa0IsRUFBRSxLQUFhO1FBQzdDLElBQUksSUFBSSxHQUFHLHNDQUFzQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUVsSixPQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRTtZQUNsQyxjQUFjLEVBQUUsa0JBQWtCO1NBQ3RDLEVBQ0QsRUFDRixDQUFDLENBQUM7SUFDWCxDQUFDO0NBQ0oifQ==
import { Service } from "../service.ts";
export class Health extends Service {
    async get() {
        let path = '/health';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getAntiVirus() {
        let path = '/health/anti-virus';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getCache() {
        let path = '/health/cache';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getDB() {
        let path = '/health/db';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueCertificates() {
        let path = '/health/queue/certificates';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueFunctions() {
        let path = '/health/queue/functions';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueLogs() {
        let path = '/health/queue/logs';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueTasks() {
        let path = '/health/queue/tasks';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueUsage() {
        let path = '/health/queue/usage';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getQueueWebhooks() {
        let path = '/health/queue/webhooks';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getStorageLocal() {
        let path = '/health/storage/local';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
    async getTime() {
        let path = '/health/time';
        return await this.client.call('get', path, {
            'content-type': 'application/json',
        }, {});
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVhbHRoLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaGVhbHRoLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFHeEMsTUFBTSxPQUFPLE1BQU8sU0FBUSxPQUFPO0lBVS9CLEtBQUssQ0FBQyxHQUFHO1FBQ0wsSUFBSSxJQUFJLEdBQUcsU0FBUyxDQUFDO1FBRXJCLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO1lBQy9CLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRCxFQUNGLENBQUMsQ0FBQztJQUNYLENBQUM7SUFVRCxLQUFLLENBQUMsWUFBWTtRQUNkLElBQUksSUFBSSxHQUFHLG9CQUFvQixDQUFDO1FBRWhDLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO1lBQy9CLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRCxFQUNGLENBQUMsQ0FBQztJQUNYLENBQUM7SUFXRCxLQUFLLENBQUMsUUFBUTtRQUNWLElBQUksSUFBSSxHQUFHLGVBQWUsQ0FBQztRQUUzQixPQUFPLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRTtZQUMvQixjQUFjLEVBQUUsa0JBQWtCO1NBQ3RDLEVBQ0QsRUFDRixDQUFDLENBQUM7SUFDWCxDQUFDO0lBVUQsS0FBSyxDQUFDLEtBQUs7UUFDUCxJQUFJLElBQUksR0FBRyxZQUFZLENBQUM7UUFFeEIsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVlELEtBQUssQ0FBQyxvQkFBb0I7UUFDdEIsSUFBSSxJQUFJLEdBQUcsNEJBQTRCLENBQUM7UUFFeEMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVFELEtBQUssQ0FBQyxpQkFBaUI7UUFDbkIsSUFBSSxJQUFJLEdBQUcseUJBQXlCLENBQUM7UUFFckMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVdELEtBQUssQ0FBQyxZQUFZO1FBQ2QsSUFBSSxJQUFJLEdBQUcsb0JBQW9CLENBQUM7UUFFaEMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVdELEtBQUssQ0FBQyxhQUFhO1FBQ2YsSUFBSSxJQUFJLEdBQUcscUJBQXFCLENBQUM7UUFFakMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVdELEtBQUssQ0FBQyxhQUFhO1FBQ2YsSUFBSSxJQUFJLEdBQUcscUJBQXFCLENBQUM7UUFFakMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVdELEtBQUssQ0FBQyxnQkFBZ0I7UUFDbEIsSUFBSSxJQUFJLEdBQUcsd0JBQXdCLENBQUM7UUFFcEMsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQVVELEtBQUssQ0FBQyxlQUFlO1FBQ2pCLElBQUksSUFBSSxHQUFHLHVCQUF1QixDQUFDO1FBRW5DLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO1lBQy9CLGNBQWMsRUFBRSxrQkFBa0I7U0FDdEMsRUFDRCxFQUNGLENBQUMsQ0FBQztJQUNYLENBQUM7SUFnQkQsS0FBSyxDQUFDLE9BQU87UUFDVCxJQUFJLElBQUksR0FBRyxjQUFjLENBQUM7UUFFMUIsT0FBTyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDL0IsY0FBYyxFQUFFLGtCQUFrQjtTQUN0QyxFQUNELEVBQ0YsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztDQUNKIn0=